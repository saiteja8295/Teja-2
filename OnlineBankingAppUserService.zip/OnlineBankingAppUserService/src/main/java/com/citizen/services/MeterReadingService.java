package com.citizen.services;

import java.util.List;
import java.util.Optional;
import com.citizen.models.MeterReading;

public interface MeterReadingService {
    Optional<MeterReading> getReadingById(int readingId);
    List<MeterReading> getAllReadings();
    MeterReading addReading(Double reading);
    
	MeterReading simulateReading();
}
