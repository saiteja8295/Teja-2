package com.citizen.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.citizen.models.MeterReading;
import com.citizen.services.MeterReadingService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/meter")
public class MeterReadingController {
    @Autowired
    private MeterReadingService meterReadingService;

    @GetMapping("/reading/{id}")
    public Optional<MeterReading> getReadingById(@PathVariable int id) {
        return meterReadingService.getReadingById(id);
    }

    @GetMapping("/readings")
    public List<MeterReading> getAllReadings() {
        return meterReadingService.getAllReadings();
    }

    @PostMapping("/reading")
    public MeterReading addReading(@RequestBody Double reading) {
        return meterReadingService.addReading(reading);
    }

    @PostMapping("/simulate")
    public MeterReading simulateReading() {
        return meterReadingService.simulateReading();
    }
}
