package com.citizen.servicesImplementation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citizen.models.MeterReading;
import com.citizen.repositories.MeterReadingRepo;
import com.citizen.services.MeterReadingService;

import java.util.List;
import java.util.Optional;

@Service
public class MeterReadingServiceImp implements MeterReadingService {
    @Autowired
    private MeterReadingRepo meterReadingRepo;

    private Double lastReading = 0.0;

    @Override
    public Optional<MeterReading> getReadingById(int readingId) {
        return meterReadingRepo.findById(readingId);
    }

    @Override
    public List<MeterReading> getAllReadings() {
        return meterReadingRepo.findAll();
    }

    @Override
    public MeterReading addReading(Double reading) {
        if (reading <= lastReading) {
            throw new IllegalArgumentException("New reading must be greater than the last reading.");
        }
        MeterReading meterReading = new MeterReading(reading);
        lastReading = reading; // Update the last reading
        return meterReadingRepo.save(meterReading);
    }

    @Override
    public MeterReading simulateReading() {
        double newReading = Math.random() * (100 - 1) + lastReading + 1; // Random reading greater than last
        return addReading(newReading);
    }
}
