package com.citizen.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.citizen.models.MeterReading;

public interface MeterReadingRepo extends JpaRepository<MeterReading, Integer> {
    Optional<MeterReading> findById(Integer id);
}
