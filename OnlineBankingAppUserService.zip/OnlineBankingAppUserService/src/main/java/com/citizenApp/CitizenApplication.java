package com.citizenApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import brave.sampler.Sampler;

@EnableEurekaClient
@SpringBootApplication
public class CitizenApplication {
    public static void main(String[] args) {
        SpringApplication.run(CitizenApplication.class, args);
    }

    public Sampler alwaysSampler() {
        return Sampler.ALWAYS_SAMPLE;
    }
}
